package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import android.widget.Button;
import android.widget.GridView;
import android.widget.ListAdapter;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

import android.widget.EditText;

import android.widget.TableLayout;

import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.telephony.SmsManager;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper db;
    EditText inputItem;
    Button addBtn, smsBtn;
    TableLayout table;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        inputItem = findViewById(R.id.inputItem);
        addBtn = findViewById(R.id.addButton);
        smsBtn = findViewById(R.id.smsButton);
        table = findViewById(R.id.tableLayout);

        loadTable();

        addBtn.setOnClickListener(v -> {
            String item = inputItem.getText().toString();
            db.addItem(item);
            loadTable();
        });

        smsBtn.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
            } else {
                SmsManager.getDefault().sendTextMessage("1234567890", null,
                        "This is your alert!", null, null);
                Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadTable() {
        table.removeAllViews();
        Cursor cursor = db.getAllItems();
        while (cursor.moveToNext()) {
            TableRow row = new TableRow(this);
            TextView itemText = new TextView(this);
            itemText.setText(cursor.getString(1));
            Button deleteBtn = new Button(this);
            deleteBtn.setText("Delete");
            int id = cursor.getInt(0);
            deleteBtn.setOnClickListener(v -> {
                db.deleteItem(id);
                loadTable();
            });
            row.addView(itemText);
            row.addView(deleteBtn);
            table.addView(row);
        }
    }
}
